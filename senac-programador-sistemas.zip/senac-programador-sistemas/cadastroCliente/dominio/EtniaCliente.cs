﻿using cadastroCliente.dominio;

namespace cadastroCliente
{
    internal enum EtniaCliente
    {
        Branco,
        Negro,
        Pardo,
        Amarelo,
        Indígena
    }
}
