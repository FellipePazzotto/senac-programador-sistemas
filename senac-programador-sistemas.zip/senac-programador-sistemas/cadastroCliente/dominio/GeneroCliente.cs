﻿using cadastroCliente.dominio;

namespace cadastroCliente
{
    internal enum GeneroCliente
    {
        Masculino,
        Feminino,
        Outros
    }
}
